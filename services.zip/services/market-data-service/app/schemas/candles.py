from datetime import datetime

from pydantic import BaseModel, Field, field_validator, model_validator


VALID_TIMEFRAMES = {
    "1m",
    "3m",
    "5m",
    "15m",
    "30m",
    "1h",
    "2h",
    "4h",
    "6h",
    "8h",
    "12h",
    "1d",
    "3d",
    "1w",
    "1M",
}


class FetchCandlesRequest(BaseModel):
    symbol: str = Field(..., examples=["BTC-USDT"])
    timeframe: str = Field(..., examples=["1h"])
    start_time: datetime | None = None
    end_time: datetime | None = None
    limit: int = Field(default=500, ge=1, le=1440)

    @field_validator("symbol")
    @classmethod
    def normalize_symbol(cls, value: str) -> str:
        value = value.strip().upper()
        if not value or "-" not in value:
            raise ValueError("symbol must use BingX format, for example BTC-USDT")
        return value

    @field_validator("timeframe")
    @classmethod
    def validate_timeframe(cls, value: str) -> str:
        if value not in VALID_TIMEFRAMES:
            raise ValueError(f"timeframe must be one of: {', '.join(sorted(VALID_TIMEFRAMES))}")
        return value

    @model_validator(mode="after")
    def validate_time_range(self) -> "FetchCandlesRequest":
        if self.start_time is not None and self.end_time is not None and self.start_time > self.end_time:
            raise ValueError("start_time must be earlier than or equal to end_time")
        return self


class CandleOutput(BaseModel):
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float


class FetchCandlesResponse(BaseModel):
    symbol: str
    timeframe: str
    fetched_count: int
    saved_count: int
    candles: list[CandleOutput] = Field(default_factory=list)
