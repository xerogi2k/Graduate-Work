import asyncio
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from typing import Any

import httpx

from app.core.config import Settings


class BingXAPIError(RuntimeError):
    """Raised when BingX returns an error or an invalid response."""


@dataclass(frozen=True)
class CandleData:
    timestamp: datetime
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal


class BingXFuturesClient:
    KLINES_PATH = "/openApi/swap/v3/quote/klines"

    def __init__(self, settings: Settings) -> None:
        self._base_url = settings.bingx_base_url.rstrip("/")
        self._timeout = settings.bingx_request_timeout_seconds
        self._retry_attempts = settings.bingx_retry_attempts
        self._retry_backoff = settings.bingx_retry_backoff_seconds

    async def fetch_klines(
        self,
        symbol: str,
        interval: str,
        start_time: datetime | None,
        end_time: datetime | None,
        limit: int,
    ) -> list[CandleData]:
        params: dict[str, Any] = {
            "symbol": symbol,
            "interval": interval,
            "limit": limit,
            "timestamp": int(time.time() * 1000),
        }
        if start_time is not None:
            params["startTime"] = self._to_milliseconds(start_time)
        if end_time is not None:
            params["endTime"] = self._to_milliseconds(end_time)

        payload = await self._get_json(self.KLINES_PATH, params=params)
        data = payload.get("data")
        if not isinstance(data, list):
            raise BingXAPIError("BingX returned an invalid candles payload")

        return [self._parse_candle(item) for item in data]

    async def _get_json(self, path: str, params: dict[str, Any]) -> dict[str, Any]:
        url = f"{self._base_url}{path}"
        last_error: Exception | None = None

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            for attempt in range(1, self._retry_attempts + 1):
                try:
                    response = await client.get(url, params=params)
                    if response.status_code >= 500:
                        response.raise_for_status()
                    if response.status_code >= 400:
                        raise BingXAPIError(
                            f"BingX request failed with status {response.status_code}: {response.text}"
                        )

                    payload = response.json()
                    code = payload.get("code")
                    if code not in (0, "0"):
                        message = payload.get("msg") or payload.get("message") or "unknown error"
                        raise BingXAPIError(f"BingX API error {code}: {message}")
                    return payload
                except (httpx.HTTPError, ValueError) as exc:
                    last_error = exc
                    if attempt == self._retry_attempts:
                        break
                    await asyncio.sleep(self._retry_backoff * attempt)

        raise BingXAPIError(f"BingX request failed after {self._retry_attempts} attempts: {last_error}")

    @staticmethod
    def _parse_candle(raw: Any) -> CandleData:
        try:
            if isinstance(raw, dict):
                return CandleData(
                    timestamp=datetime.fromtimestamp(int(raw["time"]) / 1000, tz=UTC),
                    open=Decimal(str(raw["open"])),
                    high=Decimal(str(raw["high"])),
                    low=Decimal(str(raw["low"])),
                    close=Decimal(str(raw["close"])),
                    volume=Decimal(str(raw["volume"])),
                )

            if isinstance(raw, list) and len(raw) >= 6:
                return CandleData(
                    timestamp=datetime.fromtimestamp(int(raw[0]) / 1000, tz=UTC),
                    open=Decimal(str(raw[1])),
                    high=Decimal(str(raw[2])),
                    low=Decimal(str(raw[3])),
                    close=Decimal(str(raw[4])),
                    volume=Decimal(str(raw[5])),
                )
        except (InvalidOperation, KeyError, TypeError, ValueError) as exc:
            raise BingXAPIError(f"Failed to parse BingX candle item: {raw}") from exc

        raise BingXAPIError(f"BingX returned an invalid candle item: {raw}")

    @staticmethod
    def _to_milliseconds(value: datetime) -> int:
        if value.tzinfo is None:
            value = value.replace(tzinfo=UTC)
        return int(value.timestamp() * 1000)
