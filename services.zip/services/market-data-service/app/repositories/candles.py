from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.clients.bingx import CandleData
from app.models.candle import Candle


class CandleRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def upsert_many(self, symbol: str, timeframe: str, candles: list[CandleData]) -> int:
        if not candles:
            return 0

        rows = [
            {
                "symbol": symbol,
                "timeframe": timeframe,
                "timestamp": candle.timestamp,
                "open": candle.open,
                "high": candle.high,
                "low": candle.low,
                "close": candle.close,
                "volume": candle.volume,
            }
            for candle in candles
        ]

        statement = insert(Candle).values(rows)
        excluded = statement.excluded
        statement = statement.on_conflict_do_update(
            constraint="uq_candles_symbol_timeframe_timestamp",
            set_={
                "open": excluded.open,
                "high": excluded.high,
                "low": excluded.low,
                "close": excluded.close,
                "volume": excluded.volume,
            },
        )

        await self._session.execute(statement)
        return len(rows)
