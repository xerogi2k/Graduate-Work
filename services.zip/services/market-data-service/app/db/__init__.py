"""Database setup for market data service."""
