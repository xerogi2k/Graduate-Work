"""Market data service package."""
