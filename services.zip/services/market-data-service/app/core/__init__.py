"""Core configuration for market data service."""
