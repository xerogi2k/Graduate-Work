from functools import lru_cache

from shared.config import BaseServiceSettings


class Settings(BaseServiceSettings):
    service_name: str = "market-data-service"
    bingx_base_url: str = "https://open-api.bingx.com"
    bingx_request_timeout_seconds: float = 10.0
    bingx_retry_attempts: int = 3
    bingx_retry_backoff_seconds: float = 0.5


@lru_cache
def get_settings() -> Settings:
    return Settings()
