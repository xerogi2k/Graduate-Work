"""API routes for market data service."""
