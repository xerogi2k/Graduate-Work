import logging

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

from app.clients.bingx import BingXAPIError, BingXFuturesClient, CandleData
from app.core.config import get_settings
from app.db.session import get_db_session
from app.repositories.candles import CandleRepository
from app.schemas.candles import CandleOutput, FetchCandlesRequest, FetchCandlesResponse
from shared.schemas.health import HealthResponse

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/health", response_model=HealthResponse, tags=["system"])
async def health() -> HealthResponse:
    settings = get_settings()
    return HealthResponse(service=settings.service_name)


@router.post(
    "/fetch-candles",
    response_model=FetchCandlesResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["market-data"],
)
async def fetch_candles(
    request: FetchCandlesRequest,
    session: AsyncSession = Depends(get_db_session),
) -> FetchCandlesResponse:
    settings = get_settings()
    client = BingXFuturesClient(settings=settings)
    repository = CandleRepository(session=session)

    try:
        candles = await client.fetch_klines(
            symbol=request.symbol,
            interval=request.timeframe,
            start_time=request.start_time,
            end_time=request.end_time,
            limit=request.limit,
        )
        saved_count = await repository.upsert_many(
            symbol=request.symbol,
            timeframe=request.timeframe,
            candles=candles,
        )
        await session.commit()
    except BingXAPIError as exc:
        logger.warning("BingX candle fetch failed: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(exc),
        ) from exc
    except SQLAlchemyError as exc:
        await session.rollback()
        logger.exception("Failed to save candles")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to save candles",
        ) from exc

    return FetchCandlesResponse(
        symbol=request.symbol,
        timeframe=request.timeframe,
        fetched_count=len(candles),
        saved_count=saved_count,
        candles=[_to_candle_output(candle) for candle in sorted(candles, key=lambda item: item.timestamp)],
    )


def _to_candle_output(candle: CandleData) -> CandleOutput:
    return CandleOutput(
        timestamp=candle.timestamp,
        open=float(candle.open),
        high=float(candle.high),
        low=float(candle.low),
        close=float(candle.close),
        volume=float(candle.volume),
    )
