from app.schemas.signal import SignalRequest, SignalResponse


MAX_BUY_EMA20_DISTANCE = 0.006
MAX_SHORT_SOFT_EMA20_DISTANCE = 0.018
MIN_SHORT_SOFT_TREND_STRENGTH = 0.002
MIN_SHORT_RANGE_TREND_STRENGTH = 0.0035
MIN_SHORT_VOLATILE_TREND_STRENGTH = 0.0045


def generate_signal(
    *,
    request: SignalRequest,
    buy_threshold: float,
    sell_threshold: float,
    trend_filter_mode: str = "strict",
) -> SignalResponse:
    probability = request.probability
    side = "HOLD"
    confidence = 0.0
    reason = "probability_below_threshold"

    if request.signal_direction == "long" and probability >= buy_threshold:
        if _trend_allows_buy(request, trend_filter_mode=trend_filter_mode):
            side = "BUY"
            confidence = probability
            reason = "probability_and_trend"
        else:
            reason = "blocked_by_trend_filter"
    elif request.signal_direction == "short" and probability >= buy_threshold:
        if _trend_allows_sell(request, trend_filter_mode=trend_filter_mode):
            side = "SELL"
            confidence = probability
            reason = "probability_and_trend"
        else:
            reason = "blocked_by_trend_filter"
    elif request.signal_direction == "long" and probability <= sell_threshold:
        reason = "probability_below_threshold"

    return SignalResponse(
        symbol=request.symbol.upper(),
        side=side,
        confidence=confidence,
        probability=probability,
        reason=reason,
        signal_direction=request.signal_direction,
        trend_direction=request.trend_direction,
        trend_strength=request.trend_strength,
        market_regime=request.market_regime,
        ema_20_distance=request.ema_20_distance,
    )


def _trend_allows_buy(request: SignalRequest, *, trend_filter_mode: str) -> bool:
    if trend_filter_mode == "off":
        return True
    if request.market_regime == "high_volatility":
        return False
    if trend_filter_mode == "soft":
        if request.trend_direction == "down":
            return False
        if request.ema_20_distance is None:
            return True
        return request.ema_20_distance <= MAX_BUY_EMA20_DISTANCE * 1.5
    if request.trend_direction is None:
        return True
    if request.trend_direction != "up":
        return False
    if request.ema_20_distance is None:
        return True
    return request.ema_20_distance <= MAX_BUY_EMA20_DISTANCE


def _trend_allows_sell(request: SignalRequest, *, trend_filter_mode: str) -> bool:
    if trend_filter_mode == "off":
        return True
    if trend_filter_mode == "soft":
        if request.market_regime == "high_volatility":
            return _volatile_bearish_momentum(request)
        if request.trend_direction != "down":
            return False
        if request.trend_strength is not None and request.trend_strength < MIN_SHORT_SOFT_TREND_STRENGTH:
            return False
        if request.market_regime == "range":
            if request.trend_strength is None or request.trend_strength < MIN_SHORT_RANGE_TREND_STRENGTH:
                return False
        if request.ema_20_distance is None:
            return True
        return request.ema_20_distance >= -MAX_SHORT_SOFT_EMA20_DISTANCE
    if request.market_regime == "high_volatility":
        return False
    if request.trend_direction is None:
        return True
    if request.trend_direction != "down":
        return False
    if request.ema_20_distance is None:
        return True
    return request.ema_20_distance >= -MAX_BUY_EMA20_DISTANCE


def _volatile_bearish_momentum(request: SignalRequest) -> bool:
    if request.trend_direction != "down":
        return False
    if request.trend_strength is not None and request.trend_strength < MIN_SHORT_VOLATILE_TREND_STRENGTH:
        return False
    if request.ema_20_distance is None:
        return True
    return request.ema_20_distance >= -MAX_SHORT_SOFT_EMA20_DISTANCE
