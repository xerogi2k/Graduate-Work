"""Strategy domain services."""
