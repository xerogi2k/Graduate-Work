from typing import Literal

from pydantic import BaseModel, Field


Side = Literal["BUY", "SELL", "HOLD"]


class SignalRequest(BaseModel):
    symbol: str = Field(..., examples=["SOL-USDT"])
    probability: float = Field(..., ge=0, le=1)
    signal_direction: Literal["long", "short"] = "long"
    trend_direction: Literal["up", "down", "flat"] | None = None
    trend_strength: float | None = None
    market_regime: Literal["trend", "range", "high_volatility"] | None = None
    ema_20_distance: float | None = None


class SignalBatchRequest(BaseModel):
    items: list[SignalRequest] = Field(..., min_length=1)
    buy_threshold: float | None = Field(default=None, ge=0, le=1)
    sell_threshold: float | None = Field(default=None, ge=0, le=1)
    trend_filter_mode: Literal["strict", "soft", "off"] = "strict"


class SignalResponse(BaseModel):
    symbol: str
    side: Side
    confidence: float = Field(..., ge=0, le=1)
    probability: float = Field(..., ge=0, le=1)
    reason: str = "probability"
    signal_direction: Literal["long", "short"] = "long"
    trend_direction: Literal["up", "down", "flat"] | None = None
    trend_strength: float | None = None
    market_regime: Literal["trend", "range", "high_volatility"] | None = None
    ema_20_distance: float | None = None


class SignalBatchResponse(BaseModel):
    signals: list[SignalResponse]
