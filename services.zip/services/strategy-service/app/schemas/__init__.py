"""API schemas for strategy service."""
