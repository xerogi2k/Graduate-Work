from fastapi import APIRouter

from app.core.config import get_settings
from app.schemas.signal import SignalBatchRequest, SignalBatchResponse, SignalRequest, SignalResponse
from app.services.signal_generator import generate_signal
from shared.schemas.health import HealthResponse

router = APIRouter()


@router.get("/health", response_model=HealthResponse, tags=["system"])
async def health() -> HealthResponse:
    settings = get_settings()
    return HealthResponse(service=settings.service_name)


@router.post("/signal", response_model=SignalResponse, tags=["strategy"])
async def signal(request: SignalRequest) -> SignalResponse:
    settings = get_settings()
    return generate_signal(
        request=request,
        buy_threshold=settings.buy_probability_threshold,
        sell_threshold=settings.sell_probability_threshold,
        trend_filter_mode="strict",
    )


@router.post("/signals", response_model=SignalBatchResponse, tags=["strategy"])
async def signals(request: SignalBatchRequest) -> SignalBatchResponse:
    settings = get_settings()
    buy_threshold = request.buy_threshold if request.buy_threshold is not None else settings.buy_probability_threshold
    sell_threshold = request.sell_threshold if request.sell_threshold is not None else settings.sell_probability_threshold
    return SignalBatchResponse(
        signals=[
            generate_signal(
                request=item,
                buy_threshold=buy_threshold,
                sell_threshold=sell_threshold,
                trend_filter_mode=request.trend_filter_mode,
            )
            for item in request.items
        ]
    )
