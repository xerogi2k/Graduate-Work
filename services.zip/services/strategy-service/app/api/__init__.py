"""API routes for strategy service."""
