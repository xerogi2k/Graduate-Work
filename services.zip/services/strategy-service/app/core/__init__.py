"""Core configuration for strategy service."""
