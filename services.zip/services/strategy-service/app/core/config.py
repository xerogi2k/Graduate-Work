from functools import lru_cache

from shared.config import BaseServiceSettings


class Settings(BaseServiceSettings):
    service_name: str = "strategy-service"
    buy_probability_threshold: float = 0.6
    sell_probability_threshold: float = 0.4


@lru_cache
def get_settings() -> Settings:
    return Settings()
