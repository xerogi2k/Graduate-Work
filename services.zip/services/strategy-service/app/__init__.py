"""Strategy service package."""
