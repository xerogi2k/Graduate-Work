from fastapi import APIRouter

from app.core.config import get_settings
from app.schemas.risk import RiskRequest, TradeDecision
from app.services.risk_engine import calculate_trade_decision
from shared.schemas.health import HealthResponse

router = APIRouter()


@router.get("/health", response_model=HealthResponse, tags=["system"])
async def health() -> HealthResponse:
    settings = get_settings()
    return HealthResponse(service=settings.service_name)


@router.post("/evaluate", response_model=TradeDecision, tags=["risk"])
async def evaluate(request: RiskRequest) -> TradeDecision:
    settings = get_settings()
    return calculate_trade_decision(
        request=request,
        risk_per_trade=settings.risk_per_trade,
        reward_to_risk_ratio=settings.reward_to_risk_ratio,
        atr_stop_multiplier=settings.atr_stop_multiplier,
        min_leverage=settings.min_leverage,
        max_leverage=settings.max_leverage,
        low_volatility_threshold=settings.low_volatility_threshold,
        high_volatility_threshold=settings.high_volatility_threshold,
    )
