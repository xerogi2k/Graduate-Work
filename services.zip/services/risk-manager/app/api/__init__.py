"""API routes for risk manager service."""
