"""Core configuration for risk manager service."""
