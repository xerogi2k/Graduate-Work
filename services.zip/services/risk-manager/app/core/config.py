from functools import lru_cache

from shared.config import BaseServiceSettings


class Settings(BaseServiceSettings):
    service_name: str = "risk-manager"
    risk_per_trade: float = 0.01
    reward_to_risk_ratio: float = 2.0
    atr_stop_multiplier: float = 1.5
    min_leverage: float = 1.0
    max_leverage: float = 5.0
    low_volatility_threshold: float = 0.01
    high_volatility_threshold: float = 0.03


@lru_cache
def get_settings() -> Settings:
    return Settings()
