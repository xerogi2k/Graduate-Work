from app.schemas.risk import RiskRequest, TradeDecision


def calculate_trade_decision(
    *,
    request: RiskRequest,
    risk_per_trade: float,
    reward_to_risk_ratio: float,
    atr_stop_multiplier: float,
    min_leverage: float,
    max_leverage: float,
    low_volatility_threshold: float,
    high_volatility_threshold: float,
) -> TradeDecision:
    if request.side == "HOLD":
        return TradeDecision(
            symbol=request.symbol.upper(),
            side="HOLD",
            confidence=request.confidence,
            leverage=0.0,
            stop_loss=None,
            take_profit=None,
            risk_amount=0.0,
            position_notional=0.0,
            quantity=0.0,
        )

    volatility_pct = request.atr / request.entry_price
    leverage = _calculate_dynamic_leverage(
        volatility_pct=volatility_pct,
        min_leverage=min_leverage,
        max_leverage=max_leverage,
        low_volatility_threshold=low_volatility_threshold,
        high_volatility_threshold=high_volatility_threshold,
    )
    stop_distance = request.atr * atr_stop_multiplier
    risk_amount = request.account_equity * risk_per_trade
    quantity = risk_amount / stop_distance
    position_notional = quantity * request.entry_price
    max_position_notional = request.account_equity * leverage

    if position_notional > max_position_notional:
        position_notional = max_position_notional
        quantity = position_notional / request.entry_price

    if request.side == "BUY":
        stop_loss = request.entry_price - stop_distance
        take_profit = request.entry_price + (stop_distance * reward_to_risk_ratio)
    else:
        stop_loss = request.entry_price + stop_distance
        take_profit = request.entry_price - (stop_distance * reward_to_risk_ratio)

    return TradeDecision(
        symbol=request.symbol.upper(),
        side=request.side,
        confidence=request.confidence,
        leverage=leverage,
        stop_loss=max(stop_loss, 0.0),
        take_profit=max(take_profit, 0.0),
        risk_amount=risk_amount,
        position_notional=position_notional,
        quantity=quantity,
    )


def _calculate_dynamic_leverage(
    *,
    volatility_pct: float,
    min_leverage: float,
    max_leverage: float,
    low_volatility_threshold: float,
    high_volatility_threshold: float,
) -> float:
    if volatility_pct <= low_volatility_threshold:
        return max_leverage
    if volatility_pct >= high_volatility_threshold:
        return min_leverage

    volatility_range = high_volatility_threshold - low_volatility_threshold
    normalized = (volatility_pct - low_volatility_threshold) / volatility_range
    return max_leverage - (normalized * (max_leverage - min_leverage))
