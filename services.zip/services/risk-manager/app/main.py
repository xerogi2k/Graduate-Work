from fastapi import FastAPI

from app.api.router import router
from app.core.config import get_settings
from shared.logging import configure_logging

settings = get_settings()
configure_logging(settings.log_level)

app = FastAPI(title="Risk Manager", version="0.1.0")
app.include_router(router)
