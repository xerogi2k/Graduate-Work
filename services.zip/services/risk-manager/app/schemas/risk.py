from typing import Literal

from pydantic import BaseModel, Field


Side = Literal["BUY", "SELL", "HOLD"]


class RiskRequest(BaseModel):
    symbol: str = Field(..., examples=["SOL-USDT"])
    side: Side
    confidence: float = Field(..., ge=0, le=1)
    account_equity: float = Field(..., gt=0)
    entry_price: float = Field(..., gt=0)
    atr: float = Field(..., gt=0)


class TradeDecision(BaseModel):
    symbol: str
    side: Side
    confidence: float = Field(..., ge=0, le=1)
    leverage: float
    stop_loss: float | None
    take_profit: float | None
    risk_amount: float
    position_notional: float
    quantity: float
