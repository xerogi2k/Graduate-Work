"""API schemas for risk manager."""
