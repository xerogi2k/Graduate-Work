from __future__ import annotations

import numpy as np
import pandas as pd


REQUIRED_OHLCV_COLUMNS = {"open", "high", "low", "close", "volume"}


def add_technical_indicators(
    ohlcv: pd.DataFrame,
    *,
    rsi_period: int = 14,
    macd_fast_period: int = 12,
    macd_slow_period: int = 26,
    macd_signal_period: int = 9,
    ema_periods: tuple[int, int] = (20, 50),
    atr_period: int = 14,
    volatility_window: int = 20,
) -> pd.DataFrame:
    """Return OHLCV data with technical indicator feature columns.

    Expected input columns: open, high, low, close, volume.
    The function preserves existing columns and index, and appends features.
    """
    _validate_ohlcv(ohlcv)

    features = ohlcv.copy()
    close = features["close"].astype(float)
    high = features["high"].astype(float)
    low = features["low"].astype(float)

    features[f"rsi_{rsi_period}"] = calculate_rsi(close, period=rsi_period)

    macd = calculate_macd(
        close,
        fast_period=macd_fast_period,
        slow_period=macd_slow_period,
        signal_period=macd_signal_period,
    )
    features = features.join(macd)

    for period in ema_periods:
        features[f"ema_{period}"] = calculate_ema(close, period=period)

    features[f"atr_{atr_period}"] = calculate_atr(
        high=high,
        low=low,
        close=close,
        period=atr_period,
    )
    features[f"rolling_volatility_{volatility_window}"] = calculate_rolling_volatility(
        close=close,
        window=volatility_window,
    )

    return features.replace([np.inf, -np.inf], np.nan)


def calculate_rsi(close: pd.Series, period: int = 14) -> pd.Series:
    _validate_positive_period(period, "period")

    delta = close.diff()
    gains = delta.clip(lower=0)
    losses = -delta.clip(upper=0)

    average_gain = gains.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    average_loss = losses.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()

    relative_strength = average_gain / average_loss
    rsi = 100 - (100 / (1 + relative_strength))

    return rsi.where(average_loss != 0, 100.0)


def calculate_macd(
    close: pd.Series,
    *,
    fast_period: int = 12,
    slow_period: int = 26,
    signal_period: int = 9,
) -> pd.DataFrame:
    _validate_positive_period(fast_period, "fast_period")
    _validate_positive_period(slow_period, "slow_period")
    _validate_positive_period(signal_period, "signal_period")
    if fast_period >= slow_period:
        raise ValueError("macd_fast_period must be lower than macd_slow_period")

    fast_ema = calculate_ema(close, period=fast_period)
    slow_ema = calculate_ema(close, period=slow_period)
    macd_line = fast_ema - slow_ema
    signal_line = calculate_ema(macd_line, period=signal_period)

    return pd.DataFrame(
        {
            "macd": macd_line,
            "macd_signal": signal_line,
            "macd_histogram": macd_line - signal_line,
        },
        index=close.index,
    )


def calculate_ema(close: pd.Series, period: int) -> pd.Series:
    _validate_positive_period(period, "period")
    return close.ewm(span=period, min_periods=period, adjust=False).mean()


def calculate_atr(
    *,
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 14,
) -> pd.Series:
    _validate_positive_period(period, "period")

    previous_close = close.shift(1)
    true_range = pd.concat(
        [
            high - low,
            (high - previous_close).abs(),
            (low - previous_close).abs(),
        ],
        axis=1,
    ).max(axis=1)

    return true_range.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()


def calculate_rolling_volatility(close: pd.Series, window: int = 20) -> pd.Series:
    _validate_positive_period(window, "window")

    log_returns = np.log(close / close.shift(1))
    return log_returns.rolling(window=window, min_periods=window).std()


def _validate_ohlcv(ohlcv: pd.DataFrame) -> None:
    missing_columns = REQUIRED_OHLCV_COLUMNS.difference(ohlcv.columns)
    if missing_columns:
        missing = ", ".join(sorted(missing_columns))
        raise ValueError(f"OHLCV data is missing required columns: {missing}")

    if ohlcv.empty:
        raise ValueError("OHLCV data must not be empty")


def _validate_positive_period(period: int, name: str) -> None:
    if period <= 0:
        raise ValueError(f"{name} must be positive")
