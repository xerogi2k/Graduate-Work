from __future__ import annotations

import numpy as np
import pandas as pd

from features.indicators import add_technical_indicators, calculate_atr, calculate_ema, calculate_rsi


MULTI_TIMEFRAME_RULES = {
    "5m": "5min",
    "15m": "15min",
    "1h": "1h",
}


def add_advanced_features(ohlcv: pd.DataFrame) -> pd.DataFrame:
    """Add market-regime and multi-timeframe features without future leakage."""
    features = add_technical_indicators(ohlcv).copy()
    features = add_market_regime_features(features)
    features = add_multi_timeframe_features(features)
    return features.replace([np.inf, -np.inf], np.nan)


def add_market_regime_features(
    data: pd.DataFrame,
    *,
    trend_threshold: float = 0.002,
    volatility_window: int = 20,
    volatility_quantile_window: int = 100,
    high_volatility_quantile: float = 0.75,
) -> pd.DataFrame:
    features = data.copy()
    close = features["close"].astype(float)

    ema_20 = features.get("ema_20", calculate_ema(close, period=20))
    ema_50 = features.get("ema_50", calculate_ema(close, period=50))
    volatility = features.get(
        f"rolling_volatility_{volatility_window}",
        np.log(close / close.shift(1)).rolling(window=volatility_window, min_periods=volatility_window).std(),
    )
    volatility_threshold = volatility.rolling(
        window=volatility_quantile_window,
        min_periods=volatility_window,
    ).quantile(high_volatility_quantile)

    trend_strength = ((ema_20 - ema_50).abs() / close).replace([np.inf, -np.inf], np.nan)
    trend_direction_score = ((ema_20 - ema_50) / close).replace([np.inf, -np.inf], np.nan)
    is_high_volatility = volatility > volatility_threshold
    is_trend = (trend_strength > trend_threshold) & ~is_high_volatility
    is_range = ~(is_high_volatility | is_trend)
    bullish_trend = is_trend & (ema_20 > ema_50)
    bearish_trend = is_trend & (ema_20 < ema_50)

    features["trend_strength"] = trend_strength
    features["trend_direction_score"] = trend_direction_score
    features["trend_direction"] = np.select(
        [bullish_trend, bearish_trend],
        ["up", "down"],
        default="flat",
    )
    features["market_regime"] = np.select(
        [is_high_volatility, bullish_trend | bearish_trend],
        ["high_volatility", "trend"],
        default="range",
    )
    features["regime_trend"] = is_trend.astype(int)
    features["regime_range"] = is_range.astype(int)
    features["regime_high_volatility"] = is_high_volatility.astype(int)

    return features


def add_multi_timeframe_features(data: pd.DataFrame) -> pd.DataFrame:
    if "timestamp" not in data.columns:
        raise ValueError("timestamp column is required to build multi-timeframe features")

    features = data.copy()
    features["timestamp"] = pd.to_datetime(features["timestamp"], utc=True)
    features = features.sort_values("timestamp").reset_index(drop=True)

    base_timestamps = features[["timestamp"]].copy()
    indexed_ohlcv = features.set_index("timestamp")[["open", "high", "low", "close", "volume"]].astype(float)

    for label, rule in MULTI_TIMEFRAME_RULES.items():
        timeframe_features = _build_single_timeframe_features(indexed_ohlcv, label=label, rule=rule)
        features = pd.merge_asof(
            features.sort_values("timestamp"),
            timeframe_features.reset_index().sort_values("timestamp"),
            on="timestamp",
            direction="backward",
        )

    features["timestamp"] = base_timestamps["timestamp"]
    return features


def _build_single_timeframe_features(
    indexed_ohlcv: pd.DataFrame,
    *,
    label: str,
    rule: str,
) -> pd.DataFrame:
    resampled = indexed_ohlcv.resample(rule, closed="left", label="right").agg(
        {
            "open": "first",
            "high": "max",
            "low": "min",
            "close": "last",
            "volume": "sum",
        }
    )
    resampled = resampled.dropna(subset=["open", "high", "low", "close", "volume"])
    resampled_features = pd.DataFrame(index=resampled.index)
    resampled_features.index.name = "timestamp"

    close = resampled["close"].astype(float)
    high = resampled["high"].astype(float)
    low = resampled["low"].astype(float)

    resampled_features[f"mtf_{label}_return_1"] = close.pct_change()
    resampled_features[f"mtf_{label}_rsi_14"] = calculate_rsi(close, period=14)
    resampled_features[f"mtf_{label}_ema_20_distance"] = (close / calculate_ema(close, period=20)) - 1
    resampled_features[f"mtf_{label}_atr_14_pct"] = calculate_atr(
        high=high,
        low=low,
        close=close,
        period=14,
    ) / close

    return resampled_features
