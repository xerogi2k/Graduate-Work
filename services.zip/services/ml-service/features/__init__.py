"""Feature engineering utilities for ML service."""
