from __future__ import annotations

import pandas as pd
from pandas.api.types import is_numeric_dtype

from features.advanced import add_advanced_features
from features.indicators import add_technical_indicators


DEFAULT_EXCLUDED_FEATURE_COLUMNS = {"target", "timestamp"}


def build_training_dataset(
    ohlcv: pd.DataFrame,
    *,
    horizon: int,
    threshold: float = 0.005,
    test_size: float = 0.2,
    feature_set: str = "baseline",
    target_mode: str = "future_return",
    target_direction: str = "long",
    stop_loss_threshold: float | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """Build chronological train/test data for supervised ML.

    Target equals 1 when the future close after `horizon` candles is more than
    `threshold` above the current close. Rows without enough future candles are
    dropped before the split to avoid leaking unavailable labels.
    """
    _validate_dataset_params(horizon=horizon, threshold=threshold, test_size=test_size)
    _validate_close_column(ohlcv)

    dataset = _sort_chronologically(ohlcv)
    dataset = _add_features(dataset=dataset, feature_set=feature_set).copy()
    dataset["target"] = _create_target(
        dataset=dataset,
        horizon=horizon,
        threshold=threshold,
        target_mode=target_mode,
        target_direction=target_direction,
        stop_loss_threshold=stop_loss_threshold,
    )

    feature_columns = _get_feature_columns(dataset)
    model_data = dataset.dropna(subset=[*feature_columns, "target"])
    if len(model_data) < 2:
        raise ValueError("Not enough rows to build train/test datasets after feature and target preparation")

    split_index = _get_split_index(row_count=len(model_data), test_size=test_size)

    train_data = model_data.iloc[:split_index]
    test_data = model_data.iloc[split_index:]

    X_train = train_data[feature_columns]
    X_test = test_data[feature_columns]
    y_train = train_data["target"].astype(int)
    y_test = test_data["target"].astype(int)

    return X_train, X_test, y_train, y_test


def build_feature_dataset(
    ohlcv: pd.DataFrame,
    *,
    horizon: int,
    threshold: float = 0.005,
    feature_set: str = "baseline",
    target_mode: str = "future_return",
    target_direction: str = "long",
    stop_loss_threshold: float | None = None,
) -> tuple[pd.DataFrame, pd.Series, pd.DataFrame]:
    """Build a chronological feature matrix and target without splitting.

    This is used by walk-forward validation, where train/test boundaries are
    created repeatedly after feature and target preparation. Features are
    still calculated only from current and past candles.
    """
    _validate_dataset_params(horizon=horizon, threshold=threshold, test_size=0.2)
    _validate_close_column(ohlcv)

    dataset = _sort_chronologically(ohlcv)
    dataset = _add_features(dataset=dataset, feature_set=feature_set).copy()
    dataset["target"] = _create_target(
        dataset=dataset,
        horizon=horizon,
        threshold=threshold,
        target_mode=target_mode,
        target_direction=target_direction,
        stop_loss_threshold=stop_loss_threshold,
    )

    feature_columns = _get_feature_columns(dataset)
    model_data = dataset.dropna(subset=[*feature_columns, "target"]).copy()
    if len(model_data) < 2:
        raise ValueError("Not enough rows to build feature dataset after feature and target preparation")

    X = model_data[feature_columns]
    y = model_data["target"].astype(int)
    return X, y, model_data


def _add_features(*, dataset: pd.DataFrame, feature_set: str) -> pd.DataFrame:
    if feature_set == "baseline":
        return add_technical_indicators(dataset)
    if feature_set == "v2":
        return add_advanced_features(dataset)
    raise ValueError("feature_set must be either 'baseline' or 'v2'")


def _create_target(
    *,
    dataset: pd.DataFrame,
    horizon: int,
    threshold: float,
    target_mode: str,
    target_direction: str,
    stop_loss_threshold: float | None,
) -> pd.Series:
    if target_direction not in {"long", "short"}:
        raise ValueError("target_direction must be either 'long' or 'short'")
    if target_mode == "future_return":
        return _create_future_return_target(
            close=dataset["close"].astype(float),
            horizon=horizon,
            threshold=threshold,
            target_direction=target_direction,
        )
    if target_mode == "barrier":
        return _create_barrier_target(
            dataset=dataset,
            horizon=horizon,
            take_profit_threshold=threshold,
            stop_loss_threshold=stop_loss_threshold if stop_loss_threshold is not None else threshold / 2,
            target_direction=target_direction,
        )
    raise ValueError("target_mode must be either 'future_return' or 'barrier'")


def _create_future_return_target(
    close: pd.Series,
    *,
    horizon: int,
    threshold: float,
    target_direction: str,
) -> pd.Series:
    future_close = close.shift(-horizon)
    future_return = (future_close / close) - 1
    if target_direction == "short":
        return (future_return < -threshold).astype("Int64").where(future_close.notna())
    return (future_return > threshold).astype("Int64").where(future_close.notna())


def _create_barrier_target(
    *,
    dataset: pd.DataFrame,
    horizon: int,
    take_profit_threshold: float,
    stop_loss_threshold: float,
    target_direction: str,
) -> pd.Series:
    _validate_barrier_columns(dataset)

    close = dataset["close"].astype(float).reset_index(drop=True)
    high = dataset["high"].astype(float).reset_index(drop=True)
    low = dataset["low"].astype(float).reset_index(drop=True)
    target = pd.Series(pd.NA, index=dataset.index, dtype="Int64")

    for index in range(len(dataset)):
        end_index = index + horizon
        if end_index >= len(dataset):
            continue

        entry_price = close.iloc[index]
        if target_direction == "short":
            take_profit_price = entry_price * (1 - take_profit_threshold)
            stop_loss_price = entry_price * (1 + stop_loss_threshold)
        else:
            take_profit_price = entry_price * (1 + take_profit_threshold)
            stop_loss_price = entry_price * (1 - stop_loss_threshold)
        label = 0

        for future_index in range(index + 1, end_index + 1):
            if target_direction == "short":
                hit_stop_loss = high.iloc[future_index] >= stop_loss_price
                hit_take_profit = low.iloc[future_index] <= take_profit_price
            else:
                hit_stop_loss = low.iloc[future_index] <= stop_loss_price
                hit_take_profit = high.iloc[future_index] >= take_profit_price

            if hit_stop_loss:
                label = 0
                break
            if hit_take_profit:
                label = 1
                break

        target.iloc[index] = label

    return target


def _get_feature_columns(dataset: pd.DataFrame) -> list[str]:
    return [
        column
        for column in dataset.columns
        if column not in DEFAULT_EXCLUDED_FEATURE_COLUMNS and is_numeric_dtype(dataset[column])
    ]


def _sort_chronologically(dataset: pd.DataFrame) -> pd.DataFrame:
    if "timestamp" in dataset.columns:
        return dataset.sort_values("timestamp").reset_index(drop=True)
    if isinstance(dataset.index, pd.DatetimeIndex):
        return dataset.sort_index()
    return dataset.reset_index(drop=True)


def _get_split_index(*, row_count: int, test_size: float) -> int:
    test_rows = max(1, int(row_count * test_size))
    train_rows = row_count - test_rows
    if train_rows <= 0:
        raise ValueError("test_size leaves no rows for training")
    return train_rows


def _validate_dataset_params(*, horizon: int, threshold: float, test_size: float) -> None:
    if horizon <= 0:
        raise ValueError("horizon must be positive")
    if threshold < 0:
        raise ValueError("threshold must be non-negative")
    if not 0 < test_size < 1:
        raise ValueError("test_size must be between 0 and 1")


def _validate_close_column(ohlcv: pd.DataFrame) -> None:
    if "close" not in ohlcv.columns:
        raise ValueError("OHLCV data is missing required column: close")


def _validate_barrier_columns(ohlcv: pd.DataFrame) -> None:
    missing_columns = {"high", "low", "close"}.difference(ohlcv.columns)
    if missing_columns:
        missing = ", ".join(sorted(missing_columns))
        raise ValueError(f"OHLCV data is missing required columns for barrier target: {missing}")
