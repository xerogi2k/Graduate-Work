from __future__ import annotations

import sys
import tempfile
import types
import unittest
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

SERVICE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SERVICE_ROOT))
sys.path.insert(0, str(SERVICE_ROOT / "app"))


class FakeModel:
    feature_importances_ = None

    def predict(self, X_test: pd.DataFrame) -> np.ndarray:
        return np.zeros(len(X_test), dtype=int)

    def predict_proba(self, X_test: pd.DataFrame) -> np.ndarray:
        negative = np.ones(len(X_test), dtype=float)
        positive = np.zeros(len(X_test), dtype=float)
        return np.column_stack([negative, positive])

    def save_model(self, path: Path) -> None:
        path.write_text("{}", encoding="utf-8")


sklearn_module = types.ModuleType("sklearn")
metrics_module = types.ModuleType("sklearn.metrics")
metrics_module.accuracy_score = lambda y_true, y_pred: 0.0
metrics_module.f1_score = lambda y_true, y_pred, zero_division=0: 0.0
metrics_module.precision_score = lambda y_true, y_pred, zero_division=0: 0.0
metrics_module.recall_score = lambda y_true, y_pred, zero_division=0: 0.0
sys.modules.setdefault("sklearn", sklearn_module)
sys.modules.setdefault("sklearn.metrics", metrics_module)
xgboost_model_module = types.ModuleType("app.ml.xgboost_model")
xgboost_model_module.train_xgboost_classifier = lambda **kwargs: FakeModel()
sys.modules.setdefault("app.ml.xgboost_model", xgboost_model_module)

from app.schemas.training import TrainRequest, WalkForwardRequest  # noqa: E402
from app.services import training  # noqa: E402


def make_candles(count: int) -> list[dict[str, object]]:
    start = datetime(2024, 1, 1, tzinfo=UTC)
    return [
        {
            "timestamp": start + timedelta(hours=index),
            "open": 100.0 + index,
            "high": 101.0 + index,
            "low": 99.0 + index,
            "close": 100.5 + index,
            "volume": 1_000.0 + index,
        }
        for index in range(count)
    ]


def make_feature_dataset(row_count: int) -> tuple[pd.DataFrame, pd.Series, pd.DataFrame]:
    timestamps = [datetime(2024, 1, 1, tzinfo=UTC) + timedelta(hours=index) for index in range(row_count)]
    X = pd.DataFrame({"feature": np.arange(row_count, dtype=float)})
    y = pd.Series([index % 2 for index in range(row_count)], dtype=int)
    model_data = pd.DataFrame(
        {
            "timestamp": timestamps,
            "open": np.arange(row_count, dtype=float) + 100.0,
            "high": np.arange(row_count, dtype=float) + 101.0,
            "low": np.arange(row_count, dtype=float) + 99.0,
            "close": np.arange(row_count, dtype=float) + 100.5,
            "volume": np.arange(row_count, dtype=float) + 1_000.0,
            "target": y,
        }
    )
    return X, y, model_data


class TrainingPurgedSplitTests(unittest.TestCase):
    def test_walk_forward_excludes_last_horizon_rows_from_training(self) -> None:
        captured: dict[str, list[int]] = {}

        def fake_train(*, X_train: pd.DataFrame, y_train: pd.Series, random_state: int) -> FakeModel:
            captured["train_index"] = list(X_train.index)
            return FakeModel()

        with (
            patch.object(training, "build_feature_dataset", return_value=make_feature_dataset(800)),
            patch.object(training, "train_xgboost_classifier", side_effect=fake_train),
        ):
            response = training.run_walk_forward_validation(
                request=WalkForwardRequest(
                    candles=make_candles(800),
                    horizon=4,
                    threshold=0.01,
                    train_window=600,
                    test_window=120,
                    step_size=120,
                    max_folds=1,
                ),
                feature_set="v2",
            )

        self.assertEqual(response.folds[0].train_rows, 596)
        self.assertEqual(captured["train_index"][0], 0)
        self.assertEqual(captured["train_index"][-1], 595)
        self.assertNotIn(596, captured["train_index"])
        self.assertNotIn(599, captured["train_index"])

    def test_walk_forward_test_window_starts_at_original_train_end(self) -> None:
        with (
            patch.object(training, "build_feature_dataset", return_value=make_feature_dataset(800)),
            patch.object(training, "train_xgboost_classifier", return_value=FakeModel()),
        ):
            response = training.run_walk_forward_validation(
                request=WalkForwardRequest(
                    candles=make_candles(800),
                    horizon=4,
                    threshold=0.01,
                    train_window=600,
                    test_window=120,
                    step_size=120,
                    max_folds=1,
                ),
                feature_set="v2",
            )

        self.assertEqual(response.predictions[0].timestamp, datetime(2024, 1, 26, tzinfo=UTC))
        self.assertEqual(response.folds[0].test_rows, 120)

    def test_regular_train_test_split_excludes_last_horizon_rows_from_training(self) -> None:
        captured: dict[str, list[int]] = {}

        def fake_train(*, X_train: pd.DataFrame, y_train: pd.Series, random_state: int) -> FakeModel:
            captured["train_index"] = list(X_train.index)
            return FakeModel()

        with (
            tempfile.TemporaryDirectory() as tmpdir,
            patch.object(training, "build_feature_dataset", return_value=make_feature_dataset(1000)),
            patch.object(training, "train_xgboost_classifier", side_effect=fake_train),
        ):
            response = training.train_baseline_model(
                request=TrainRequest(
                    candles=make_candles(1000),
                    horizon=4,
                    threshold=0.01,
                    test_size=0.2,
                ),
                artifact_dir=tmpdir,
            )

        self.assertEqual(response.train_rows, 796)
        self.assertEqual(response.test_rows, 200)
        self.assertEqual(captured["train_index"][-1], 795)
        self.assertNotIn(796, captured["train_index"])
        self.assertNotIn(799, captured["train_index"])


if __name__ == "__main__":
    unittest.main()
