from functools import lru_cache

from shared.config import BaseServiceSettings


class Settings(BaseServiceSettings):
    service_name: str = "ml-service"
    model_artifact_dir: str = "/app/artifacts/models"


@lru_cache
def get_settings() -> Settings:
    return Settings()
