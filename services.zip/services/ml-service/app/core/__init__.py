"""Core configuration for ML service."""
