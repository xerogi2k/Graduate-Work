from __future__ import annotations

import pandas as pd
from xgboost import XGBClassifier


def create_xgboost_classifier(*, random_state: int = 42) -> XGBClassifier:
    return XGBClassifier(
        n_estimators=100,
        max_depth=3,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        objective="binary:logistic",
        eval_metric="logloss",
        random_state=random_state,
    )


def train_xgboost_classifier(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    *,
    random_state: int = 42,
) -> XGBClassifier:
    model = create_xgboost_classifier(random_state=random_state)
    model.fit(X_train, y_train)
    return model
