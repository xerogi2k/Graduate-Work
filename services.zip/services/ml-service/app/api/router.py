from fastapi import APIRouter, HTTPException, status

from app.core.config import get_settings
from app.schemas.training import ModelComparisonResponse, TrainRequest, TrainResponse, WalkForwardRequest, WalkForwardResponse
from app.services.training import (
    ModelTrainingError,
    run_walk_forward_validation,
    train_and_compare_models,
    train_baseline_model,
    train_improved_model,
)
from shared.schemas.health import HealthResponse

router = APIRouter()


@router.get("/health", response_model=HealthResponse, tags=["system"])
async def health() -> HealthResponse:
    settings = get_settings()
    return HealthResponse(service=settings.service_name)


@router.post("/train", response_model=TrainResponse, tags=["ml"])
async def train(request: TrainRequest) -> TrainResponse:
    settings = get_settings()

    try:
        return train_baseline_model(request=request, artifact_dir=settings.model_artifact_dir)
    except ModelTrainingError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc


@router.post("/train-v2", response_model=TrainResponse, tags=["ml"])
async def train_v2(request: TrainRequest) -> TrainResponse:
    settings = get_settings()

    try:
        return train_improved_model(request=request, artifact_dir=settings.model_artifact_dir)
    except ModelTrainingError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc


@router.post("/train/compare", response_model=ModelComparisonResponse, tags=["ml"])
async def train_compare(request: TrainRequest) -> ModelComparisonResponse:
    settings = get_settings()

    try:
        return train_and_compare_models(request=request, artifact_dir=settings.model_artifact_dir)
    except ModelTrainingError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc


@router.post("/walk-forward", response_model=WalkForwardResponse, tags=["ml"])
async def walk_forward(request: WalkForwardRequest) -> WalkForwardResponse:
    try:
        return run_walk_forward_validation(request=request, feature_set="baseline")
    except ModelTrainingError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc


@router.post("/walk-forward-v2", response_model=WalkForwardResponse, tags=["ml"])
async def walk_forward_v2(request: WalkForwardRequest) -> WalkForwardResponse:
    try:
        return run_walk_forward_validation(request=request, feature_set="v2")
    except ModelTrainingError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
