from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

from app.ml.xgboost_model import train_xgboost_classifier
from app.schemas.training import (
    ModelComparisonResponse,
    PredictionOutput,
    TrainRequest,
    TrainResponse,
    WalkForwardFoldResult,
    WalkForwardRequest,
    WalkForwardResponse,
)
from features.dataset import build_feature_dataset


class ModelTrainingError(RuntimeError):
    """Raised when model training cannot be completed."""


def train_baseline_model(*, request: TrainRequest, artifact_dir: str) -> TrainResponse:
    return _train_model(
        request=request,
        artifact_dir=artifact_dir,
        model_name=request.model_name,
        feature_set="baseline",
    )


def train_improved_model(*, request: TrainRequest, artifact_dir: str) -> TrainResponse:
    return _train_model(
        request=request,
        artifact_dir=artifact_dir,
        model_name=f"{request.model_name}_model_v2",
        feature_set="v2",
    )


def train_and_compare_models(*, request: TrainRequest, artifact_dir: str) -> ModelComparisonResponse:
    baseline = train_baseline_model(request=request, artifact_dir=artifact_dir)
    improved = train_improved_model(request=request, artifact_dir=artifact_dir)
    metric_delta = {
        metric_name: improved.metrics[metric_name] - baseline.metrics[metric_name]
        for metric_name in baseline.metrics
    }
    return ModelComparisonResponse(
        baseline_model=baseline,
        improved_model=improved,
        metric_delta=metric_delta,
    )


def run_walk_forward_validation(
    *,
    request: WalkForwardRequest,
    feature_set: str,
) -> WalkForwardResponse:
    try:
        ohlcv = _request_to_dataframe(request)
        X, y, model_data = build_feature_dataset(
            ohlcv,
            horizon=request.horizon,
            threshold=request.threshold,
            feature_set=feature_set,
            target_mode=request.target_mode,
            target_direction=request.target_direction,
            stop_loss_threshold=request.stop_loss_threshold,
        )
        if len(X) < request.train_window + request.test_window:
            raise ValueError("Not enough rows for requested train_window and test_window")

        folds: list[WalkForwardFoldResult] = []
        all_prediction_rows: list[PredictionOutput] = []
        all_predictions: list[int] = []
        all_y_true: list[int] = []
        total_train_rows = 0

        fold_index = 0
        start_index = 0
        while fold_index < request.max_folds:
            train_start = start_index
            train_end = train_start + request.train_window
            test_end = train_end + request.test_window
            if test_end > len(X):
                break

            purged_train_end = _get_purged_train_end(train_end=train_end, horizon=request.horizon)
            X_train = X.iloc[train_start:purged_train_end]
            y_train = y.iloc[train_start:purged_train_end]
            X_test = X.iloc[train_end:test_end]
            y_test = y.iloc[train_end:test_end]

            if len(X_train) == 0:
                start_index += request.step_size
                continue
            if y_train.nunique() < 2:
                start_index += request.step_size
                continue

            model = train_xgboost_classifier(
                X_train=X_train,
                y_train=y_train,
                random_state=request.random_state + fold_index,
            )
            predictions = model.predict(X_test)
            probabilities = model.predict_proba(X_test)[:, 1]
            metrics = _calculate_metrics(y_true=y_test, y_pred=predictions)
            fold_index += 1
            total_train_rows += len(X_train)

            folds.append(
                WalkForwardFoldResult(
                    fold=fold_index,
                    train_start=_get_timestamp_at(model_data, X_train.index[0]),
                    train_end=_get_timestamp_at(model_data, X_train.index[-1]),
                    test_start=_get_timestamp_at(model_data, X_test.index[0]),
                    test_end=_get_timestamp_at(model_data, X_test.index[-1]),
                    train_rows=len(X_train),
                    test_rows=len(X_test),
                    positive_rate=float(y_test.mean()),
                    metrics=metrics,
                )
            )
            all_prediction_rows.extend(
                _build_prediction_rows(
                    ohlcv=model_data,
                    X_test=X_test,
                    probabilities=probabilities,
                    predictions=predictions,
                )
            )
            all_predictions.extend(int(value) for value in predictions)
            all_y_true.extend(int(value) for value in y_test)

            start_index += request.step_size

        if not folds:
            raise ValueError("No valid walk-forward folds could be built; try larger data depth or smaller windows")

        y_true_series = pd.Series(all_y_true)
        y_pred_series = pd.Series(all_predictions)
        aggregate_metrics = _calculate_metrics(y_true=y_true_series, y_pred=y_pred_series)
    except ValueError as exc:
        raise ModelTrainingError(str(exc)) from exc

    return WalkForwardResponse(
        folds=folds,
        fold_count=len(folds),
        train_window=request.train_window,
        test_window=request.test_window,
        step_size=request.step_size,
        total_train_rows=total_train_rows,
        total_test_rows=len(all_prediction_rows),
        positive_rate=float(y_true_series.mean()),
        metrics=aggregate_metrics,
        feature_count=len(X.columns),
        predictions=all_prediction_rows,
    )


def _train_model(
    *,
    request: TrainRequest,
    artifact_dir: str,
    model_name: str,
    feature_set: str,
) -> TrainResponse:
    try:
        ohlcv = _request_to_dataframe(request)
        X, y, model_data = build_feature_dataset(
            ohlcv,
            horizon=request.horizon,
            threshold=request.threshold,
            feature_set=feature_set,
            target_mode=request.target_mode,
            target_direction=request.target_direction,
            stop_loss_threshold=request.stop_loss_threshold,
        )
        split_index = _get_split_index(row_count=len(X), test_size=request.test_size)
        purged_split_index = _get_purged_train_end(train_end=split_index, horizon=request.horizon)
        X_train = X.iloc[:purged_split_index]
        X_test = X.iloc[split_index:]
        y_train = y.iloc[:purged_split_index]
        y_test = y.iloc[split_index:]

        if len(X_train) == 0:
            raise ValueError("horizon leaves no rows for training after purged split")
        if y_train.nunique() < 2:
            raise ValueError("Training target contains only one class; provide more diverse OHLCV data")
        model = train_xgboost_classifier(
            X_train=X_train,
            y_train=y_train,
            random_state=request.random_state,
        )
        predictions = model.predict(X_test)
        probabilities = model.predict_proba(X_test)[:, 1]
        metrics = _calculate_metrics(y_true=y_test, y_pred=predictions)
        feature_importance = _get_feature_importance(model=model, feature_names=list(X_train.columns))
        prediction_rows = _build_prediction_rows(
            ohlcv=model_data,
            X_test=X_test,
            probabilities=probabilities,
            predictions=predictions,
        )
        model_path, metadata_path = _save_artifacts(
            model=model,
            artifact_dir=artifact_dir,
            model_name=model_name,
            feature_set=feature_set,
            feature_names=list(X_train.columns),
            metrics=metrics,
            feature_importance=feature_importance,
            train_rows=len(X_train),
            test_rows=len(X_test),
            horizon=request.horizon,
            threshold=request.threshold,
            target_mode=request.target_mode,
            target_direction=request.target_direction,
            stop_loss_threshold=request.stop_loss_threshold,
        )
    except ValueError as exc:
        raise ModelTrainingError(str(exc)) from exc

    return TrainResponse(
        model_path=str(model_path),
        metadata_path=str(metadata_path),
        train_rows=len(X_train),
        test_rows=len(X_test),
        feature_count=len(X_train.columns),
        metrics=metrics,
        feature_importance=feature_importance,
        positive_rate=float(y_test.mean()),
        predictions=prediction_rows,
    )


def _request_to_dataframe(request: TrainRequest) -> pd.DataFrame:
    rows = [candle.model_dump() for candle in request.candles]
    dataframe = pd.DataFrame(rows)
    if "timestamp" in dataframe.columns and dataframe["timestamp"].notna().any():
        dataframe = dataframe.sort_values("timestamp").reset_index(drop=True)
    return dataframe


def _get_timestamp_at(dataframe: pd.DataFrame, index: int) -> pd.Timestamp | None:
    if "timestamp" not in dataframe.columns:
        return None
    value = dataframe.loc[index, "timestamp"]
    return None if pd.isna(value) else value


def _calculate_metrics(*, y_true: pd.Series, y_pred: pd.Series) -> dict[str, float]:
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
    }


def _get_split_index(*, row_count: int, test_size: float) -> int:
    test_rows = max(1, int(row_count * test_size))
    split_index = row_count - test_rows
    if split_index <= 0:
        raise ValueError("test_size leaves no rows for training")
    return split_index


def _get_purged_train_end(*, train_end: int, horizon: int) -> int:
    return max(0, train_end - horizon)


def _build_prediction_rows(
    *,
    ohlcv: pd.DataFrame,
    X_test: pd.DataFrame,
    probabilities,
    predictions,
) -> list[PredictionOutput]:
    rows: list[PredictionOutput] = []
    source_columns = ["timestamp", "open", "high", "low", "close", "volume"]
    context_columns = ["trend_direction", "trend_strength", "market_regime"]
    available_columns = [column for column in [*source_columns, *context_columns] if column in ohlcv.columns]
    source = ohlcv.loc[X_test.index, available_columns].copy()
    atr_values = X_test["atr_14"] if "atr_14" in X_test.columns else None
    ema_20_values = X_test["ema_20"] if "ema_20" in X_test.columns else None
    ema_50_values = X_test["ema_50"] if "ema_50" in X_test.columns else None

    for position, (_, candle) in enumerate(source.iterrows()):
        atr = None
        if atr_values is not None:
            value = atr_values.iloc[position]
            atr = None if pd.isna(value) else float(value)
        ema_20 = _nullable_float(ema_20_values.iloc[position]) if ema_20_values is not None else None
        ema_50 = _nullable_float(ema_50_values.iloc[position]) if ema_50_values is not None else None
        ema_20_distance = None
        if ema_20 is not None and ema_20 > 0:
            ema_20_distance = (float(candle["close"]) / ema_20) - 1
        trend_strength = candle.get("trend_strength")
        trend_strength = None if pd.isna(trend_strength) else float(trend_strength)

        rows.append(
            PredictionOutput(
                timestamp=candle.get("timestamp"),
                open=float(candle["open"]),
                high=float(candle["high"]),
                low=float(candle["low"]),
                close=float(candle["close"]),
                volume=float(candle["volume"]),
                probability=float(probabilities[position]),
                prediction=int(predictions[position]),
                atr=atr,
                ema_20=ema_20,
                ema_50=ema_50,
                ema_20_distance=ema_20_distance,
                trend_direction=candle.get("trend_direction"),
                trend_strength=trend_strength,
                market_regime=candle.get("market_regime"),
            )
        )

    return rows


def _nullable_float(value) -> float | None:
    return None if pd.isna(value) else float(value)


def _get_feature_importance(*, model, feature_names: list[str], top_n: int = 20) -> dict[str, float]:
    importances = getattr(model, "feature_importances_", None)
    if importances is None:
        return {}

    ranked = sorted(
        zip(feature_names, importances, strict=False),
        key=lambda item: item[1],
        reverse=True,
    )
    return {feature: float(importance) for feature, importance in ranked[:top_n]}


def _save_artifacts(
    *,
    model,
    artifact_dir: str,
    model_name: str,
    feature_set: str,
    feature_names: list[str],
    metrics: dict[str, float],
    feature_importance: dict[str, float],
    train_rows: int,
    test_rows: int,
    horizon: int,
    threshold: float,
    target_mode: str,
    target_direction: str,
    stop_loss_threshold: float | None,
) -> tuple[Path, Path]:
    output_dir = Path(artifact_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    created_at = datetime.now(tz=UTC).strftime("%Y%m%dT%H%M%SZ")
    artifact_stem = f"{model_name}_{created_at}"
    model_path = output_dir / f"{artifact_stem}.json"
    metadata_path = output_dir / f"{artifact_stem}_metadata.json"

    model.save_model(model_path)
    metadata = {
        "model_name": model_name,
        "model_type": "XGBClassifier",
        "feature_set": feature_set,
        "created_at": created_at,
        "feature_names": feature_names,
        "metrics": metrics,
        "feature_importance": feature_importance,
        "train_rows": train_rows,
        "test_rows": test_rows,
        "horizon": horizon,
        "threshold": threshold,
        "target_mode": target_mode,
        "target_direction": target_direction,
        "stop_loss_threshold": stop_loss_threshold,
    }
    metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    return model_path, metadata_path
