"""API schemas for ML service."""
