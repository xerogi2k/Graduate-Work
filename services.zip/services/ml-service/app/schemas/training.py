from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator


class CandleInput(BaseModel):
    timestamp: datetime | None = None
    open: float
    high: float
    low: float
    close: float
    volume: float


class TrainRequest(BaseModel):
    candles: list[CandleInput] = Field(..., min_length=60)
    horizon: int = Field(default=5, ge=1)
    threshold: float = Field(default=0.005, ge=0)
    target_mode: Literal["future_return", "barrier"] = "future_return"
    target_direction: Literal["long", "short"] = "long"
    stop_loss_threshold: float | None = Field(default=None, gt=0)
    test_size: float = Field(default=0.2, gt=0, lt=1)
    model_name: str = Field(default="xgboost_baseline", min_length=1, max_length=80)
    random_state: int = 42

    @field_validator("model_name")
    @classmethod
    def validate_model_name(cls, value: str) -> str:
        normalized = value.strip().replace(" ", "_")
        if not normalized:
            raise ValueError("model_name must not be empty")
        if not all(char.isalnum() or char in {"_", "-"} for char in normalized):
            raise ValueError("model_name may contain only letters, numbers, underscores, and hyphens")
        return normalized


class WalkForwardRequest(TrainRequest):
    train_window: int = Field(default=1200, ge=100)
    test_window: int = Field(default=240, ge=20)
    step_size: int = Field(default=240, ge=20)
    max_folds: int = Field(default=8, ge=1, le=50)


class PredictionOutput(BaseModel):
    timestamp: datetime | None = None
    open: float
    high: float
    low: float
    close: float
    volume: float
    probability: float = Field(..., ge=0, le=1)
    prediction: int = Field(..., ge=0, le=1)
    atr: float | None = None
    ema_20: float | None = None
    ema_50: float | None = None
    ema_20_distance: float | None = None
    trend_direction: str | None = None
    trend_strength: float | None = None
    market_regime: str | None = None


class TrainResponse(BaseModel):
    model_path: str
    metadata_path: str
    train_rows: int
    test_rows: int
    feature_count: int
    metrics: dict[str, float]
    feature_importance: dict[str, float]
    positive_rate: float
    predictions: list[PredictionOutput] = Field(default_factory=list)


class ModelComparisonResponse(BaseModel):
    baseline_model: TrainResponse
    improved_model: TrainResponse
    metric_delta: dict[str, float]


class WalkForwardFoldResult(BaseModel):
    fold: int
    train_start: datetime | None = None
    train_end: datetime | None = None
    test_start: datetime | None = None
    test_end: datetime | None = None
    train_rows: int
    test_rows: int
    positive_rate: float
    metrics: dict[str, float]


class WalkForwardResponse(BaseModel):
    folds: list[WalkForwardFoldResult]
    fold_count: int
    train_window: int
    test_window: int
    step_size: int
    total_train_rows: int
    total_test_rows: int
    positive_rate: float
    metrics: dict[str, float]
    feature_count: int
    predictions: list[PredictionOutput] = Field(default_factory=list)
