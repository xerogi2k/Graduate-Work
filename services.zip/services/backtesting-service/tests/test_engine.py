from __future__ import annotations

import unittest
from datetime import UTC, datetime, timedelta

from app.schemas.backtest import BacktestRequest, SignalCandle
from app.services.engine import run_backtest


def candle(
    index: int,
    *,
    open_: float = 100.0,
    high: float = 101.0,
    low: float = 99.0,
    close: float = 100.0,
    probability: float = 0.0,
    side: str = "HOLD",
) -> SignalCandle:
    return SignalCandle(
        timestamp=datetime(2025, 1, 1, tzinfo=UTC) + timedelta(hours=index),
        open=open_,
        high=high,
        low=low,
        close=close,
        volume=1_000.0,
        probability=probability,
        side=side,
    )


class BacktestEngineTests(unittest.TestCase):
    def test_signal_enters_on_next_candle_open(self) -> None:
        response = run_backtest(
            BacktestRequest(
                candles=[
                    candle(0, open_=100, high=101, low=99, close=100, probability=0.9, side="BUY"),
                    candle(1, open_=110, high=111, low=109, close=110, probability=0.0, side="HOLD"),
                    candle(2, open_=112, high=113, low=111, close=112, probability=0.0, side="HOLD"),
                ],
                probability_threshold=0.5,
                initial_capital=10_000.0,
                position_size_fraction=0.5,
                stop_loss_pct=0.5,
                take_profit_pct=0.5,
                max_holding_candles=1,
                fee_rate=0.0,
            )
        )

        self.assertEqual(response.total_trades, 1)
        trade = response.trades[0]
        self.assertEqual(trade.entry_timestamp, datetime(2025, 1, 1, 1, tzinfo=UTC))
        self.assertEqual(trade.entry_price, 110.0)
        self.assertEqual(trade.exit_reason, "time_exit")

    def test_signal_on_last_candle_does_not_open_trade(self) -> None:
        response = run_backtest(
            BacktestRequest(
                candles=[
                    candle(0, probability=0.0, side="HOLD"),
                    candle(1, probability=0.9, side="BUY"),
                ],
                probability_threshold=0.5,
            )
        )

        self.assertEqual(response.total_trades, 0)
        self.assertEqual(response.final_equity, 10_000.0)

    def test_stop_loss_can_trigger_after_next_open_entry(self) -> None:
        response = run_backtest(
            BacktestRequest(
                candles=[
                    candle(0, probability=0.9, side="BUY"),
                    candle(1, open_=100, high=101, low=94, close=96, probability=0.0, side="HOLD"),
                ],
                probability_threshold=0.5,
                initial_capital=10_000.0,
                position_size_fraction=0.5,
                stop_loss_pct=0.05,
                take_profit_pct=0.5,
                fee_rate=0.0,
            )
        )

        self.assertEqual(response.total_trades, 1)
        trade = response.trades[0]
        self.assertEqual(trade.entry_price, 100.0)
        self.assertEqual(trade.exit_price, 95.0)
        self.assertEqual(trade.exit_reason, "stop_loss")

    def test_entry_and_exit_fees_are_charged_without_overallocating_cash(self) -> None:
        response = run_backtest(
            BacktestRequest(
                candles=[
                    candle(0, probability=0.9, side="BUY"),
                    candle(1, open_=100, high=101, low=99, close=100, probability=0.0, side="HOLD"),
                    candle(2, open_=100, high=101, low=99, close=100, probability=0.0, side="HOLD"),
                ],
                probability_threshold=0.5,
                initial_capital=10_000.0,
                position_size_fraction=1.0,
                stop_loss_pct=0.5,
                take_profit_pct=0.5,
                max_holding_candles=1,
                fee_rate=0.001,
            )
        )

        self.assertEqual(response.total_trades, 1)
        trade = response.trades[0]
        allocated_capital = 10_000.0 / 1.001
        expected_fees = allocated_capital * 0.001 * 2
        self.assertAlmostEqual(trade.fees, expected_fees, places=6)
        self.assertAlmostEqual(response.final_equity, 10_000.0 - expected_fees, places=6)

    def test_reentry_signal_on_exit_candle_is_delayed_to_next_candle(self) -> None:
        response = run_backtest(
            BacktestRequest(
                candles=[
                    candle(0, probability=0.9, side="BUY"),
                    candle(1, open_=100, high=112, low=99, close=111, probability=0.9, side="BUY"),
                    candle(2, open_=120, high=121, low=119, close=120, probability=0.0, side="HOLD"),
                    candle(3, open_=120, high=121, low=119, close=120, probability=0.0, side="HOLD"),
                ],
                probability_threshold=0.5,
                initial_capital=10_000.0,
                position_size_fraction=0.5,
                stop_loss_pct=0.5,
                take_profit_pct=0.1,
                max_holding_candles=1,
                fee_rate=0.0,
            )
        )

        self.assertEqual(response.total_trades, 2)
        self.assertEqual(response.trades[0].entry_timestamp, datetime(2025, 1, 1, 1, tzinfo=UTC))
        self.assertEqual(response.trades[0].exit_timestamp, datetime(2025, 1, 1, 1, tzinfo=UTC))
        self.assertEqual(response.trades[1].entry_timestamp, datetime(2025, 1, 1, 2, tzinfo=UTC))

    def test_stop_loss_cooldown_skips_entries_for_requested_candles(self) -> None:
        response = run_backtest(
            BacktestRequest(
                candles=[
                    candle(0, probability=0.9, side="BUY"),
                    candle(1, open_=100, high=101, low=94, close=96, probability=0.9, side="BUY"),
                    candle(2, open_=100, high=101, low=99, close=100, probability=0.9, side="BUY"),
                    candle(3, open_=110, high=111, low=109, close=110, probability=0.9, side="BUY"),
                    candle(4, open_=112, high=113, low=111, close=112, probability=0.0, side="HOLD"),
                ],
                probability_threshold=0.5,
                initial_capital=10_000.0,
                position_size_fraction=0.5,
                stop_loss_pct=0.05,
                take_profit_pct=0.5,
                max_holding_candles=1,
                fee_rate=0.0,
                cooldown_after_stop_loss=1,
            )
        )

        self.assertEqual(response.total_trades, 2)
        self.assertEqual(response.trades[0].exit_reason, "stop_loss")
        self.assertEqual(response.trades[1].entry_timestamp, datetime(2025, 1, 1, 4, tzinfo=UTC))

    def test_rearm_requires_probability_reset_after_exit(self) -> None:
        response = run_backtest(
            BacktestRequest(
                candles=[
                    candle(0, probability=0.9, side="BUY"),
                    candle(1, open_=100, high=112, low=99, close=111, probability=0.9, side="BUY"),
                    candle(2, open_=100, high=101, low=99, close=100, probability=0.9, side="BUY"),
                    candle(3, open_=100, high=101, low=99, close=100, probability=0.4, side="HOLD"),
                    candle(4, open_=120, high=121, low=119, close=120, probability=0.9, side="BUY"),
                    candle(5, open_=120, high=121, low=119, close=120, probability=0.0, side="HOLD"),
                ],
                probability_threshold=0.5,
                rearm_probability_threshold=0.5,
                initial_capital=10_000.0,
                position_size_fraction=0.5,
                stop_loss_pct=0.5,
                take_profit_pct=0.1,
                max_holding_candles=1,
                fee_rate=0.0,
            )
        )

        self.assertEqual(response.total_trades, 2)
        self.assertEqual(response.trades[0].exit_reason, "take_profit")
        self.assertEqual(response.trades[1].entry_timestamp, datetime(2025, 1, 1, 5, tzinfo=UTC))


if __name__ == "__main__":
    unittest.main()
