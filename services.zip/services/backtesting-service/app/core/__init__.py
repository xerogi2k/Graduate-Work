"""Core configuration for backtesting service."""
