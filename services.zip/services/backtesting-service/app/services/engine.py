from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from app.schemas.backtest import BacktestRequest, BacktestResponse, EquityPoint, SignalCandle, TradeResult


class BacktestError(RuntimeError):
    """Raised when a backtest cannot be completed."""


@dataclass
class OpenPosition:
    side: str
    entry_index: int
    entry_timestamp: datetime | None
    entry_price: float
    quantity: float
    stop_loss_price: float
    take_profit_price: float
    entry_fee: float
    allocated_capital: float


def run_backtest(request: BacktestRequest) -> BacktestResponse:
    candles = _sort_candles(request.candles)
    cash = request.initial_capital
    open_position: OpenPosition | None = None
    pending_signal: SignalCandle | None = None
    cooldown_until_index = 0
    rearm_ready = True
    trades: list[TradeResult] = []
    equity_curve: list[EquityPoint] = []

    for index, candle in enumerate(candles):
        if (
            not rearm_ready
            and request.rearm_probability_threshold is not None
            and candle.probability <= request.rearm_probability_threshold
        ):
            rearm_ready = True

        if open_position is None and pending_signal is not None:
            open_position = _open_position(
                signal_candle=pending_signal,
                execution_candle=candle,
                index=index,
                cash=cash,
                position_size_fraction=request.position_size_fraction,
                stop_loss_mode=request.stop_loss_mode,
                stop_loss_pct=request.stop_loss_pct,
                atr_multiplier=request.atr_multiplier,
                take_profit_pct=request.take_profit_pct,
                take_profit_multiplier=request.take_profit_multiplier,
                fee_rate=request.fee_rate,
            )
            cash -= open_position.allocated_capital + open_position.entry_fee
            pending_signal = None

        closed_position = False
        if open_position is not None:
            exit_price, exit_reason = _get_exit(
                candle=candle,
                index=index,
                position=open_position,
                max_holding_candles=request.max_holding_candles,
            )
            if exit_price is not None:
                trade, cash = _close_position(
                    position=open_position,
                    candle=candle,
                    exit_price=exit_price,
                    exit_reason=exit_reason,
                    cash=cash,
                    fee_rate=request.fee_rate,
                )
                trades.append(trade)
                open_position = None
                closed_position = True
                exit_cooldown = _get_exit_cooldown(exit_reason=exit_reason, request=request)
                if exit_cooldown > 0:
                    cooldown_until_index = max(cooldown_until_index, index + exit_cooldown + 1)
                if request.rearm_probability_threshold is not None:
                    rearm_ready = False

        block_current_signal = closed_position and (
            request.rearm_probability_threshold is not None
            or index < cooldown_until_index
        )
        if (
            open_position is None
            and pending_signal is None
            and index >= cooldown_until_index
            and rearm_ready
            and not block_current_signal
            and candle.side in {"BUY", "SELL"}
            and candle.probability > request.probability_threshold
        ):
            pending_signal = candle

        equity_curve.append(
            EquityPoint(
                timestamp=candle.timestamp,
                equity=_calculate_mark_to_market_equity(cash=cash, position=open_position, close_price=candle.close),
            )
        )

    if open_position is not None:
        last_candle = candles[-1]
        trade, cash = _close_position(
            position=open_position,
            candle=last_candle,
            exit_price=last_candle.close,
            exit_reason="end_of_data",
            cash=cash,
            fee_rate=request.fee_rate,
        )
        trades.append(trade)
        equity_curve[-1] = EquityPoint(timestamp=last_candle.timestamp, equity=cash)

    final_equity = cash
    metrics = _calculate_metrics(
        trades=trades,
        initial_capital=request.initial_capital,
        final_equity=final_equity,
        equity_curve=equity_curve,
    )

    return BacktestResponse(
        initial_capital=request.initial_capital,
        final_equity=final_equity,
        total_pnl=final_equity - request.initial_capital,
        total_return_pct=(final_equity / request.initial_capital) - 1,
        winrate=metrics["winrate"],
        max_drawdown=metrics["max_drawdown"],
        profit_factor=metrics["profit_factor"],
        total_trades=len(trades),
        winning_trades=metrics["winning_trades"],
        losing_trades=metrics["losing_trades"],
        equity_curve=equity_curve,
        trades=trades,
    )


def _sort_candles(candles: list[SignalCandle]) -> list[SignalCandle]:
    if all(candle.timestamp is not None for candle in candles):
        return sorted(candles, key=lambda candle: candle.timestamp)
    return candles


def _get_exit_cooldown(*, exit_reason: str, request: BacktestRequest) -> int:
    if exit_reason == "stop_loss":
        return request.cooldown_after_stop_loss
    if exit_reason == "take_profit":
        return request.cooldown_after_take_profit
    if exit_reason == "time_exit":
        return request.cooldown_after_time_exit
    return 0


def _open_position(
    *,
    signal_candle: SignalCandle,
    execution_candle: SignalCandle,
    index: int,
    cash: float,
    position_size_fraction: float,
    stop_loss_mode: str,
    stop_loss_pct: float,
    atr_multiplier: float,
    take_profit_pct: float | None,
    take_profit_multiplier: float,
    fee_rate: float,
) -> OpenPosition:
    allocated_capital = (cash * position_size_fraction) / (1 + fee_rate)
    if allocated_capital <= 0:
        raise BacktestError("Not enough capital to open a position")

    entry_price = execution_candle.open
    quantity = allocated_capital / entry_price
    entry_fee = allocated_capital * fee_rate
    resolved_stop_loss_pct = _resolve_stop_loss_pct(
        candle=signal_candle,
        entry_price=entry_price,
        stop_loss_mode=stop_loss_mode,
        stop_loss_pct=stop_loss_pct,
        atr_multiplier=atr_multiplier,
    )
    resolved_take_profit_pct = take_profit_pct or resolved_stop_loss_pct * take_profit_multiplier
    if signal_candle.side == "SELL":
        stop_loss_price = entry_price * (1 + resolved_stop_loss_pct)
        take_profit_price = entry_price * (1 - resolved_take_profit_pct)
    else:
        stop_loss_price = entry_price * (1 - resolved_stop_loss_pct)
        take_profit_price = entry_price * (1 + resolved_take_profit_pct)

    return OpenPosition(
        side=signal_candle.side,
        entry_index=index,
        entry_timestamp=execution_candle.timestamp,
        entry_price=entry_price,
        quantity=quantity,
        stop_loss_price=stop_loss_price,
        take_profit_price=take_profit_price,
        entry_fee=entry_fee,
        allocated_capital=allocated_capital,
    )


def _resolve_stop_loss_pct(
    *,
    candle: SignalCandle,
    entry_price: float,
    stop_loss_mode: str,
    stop_loss_pct: float,
    atr_multiplier: float,
) -> float:
    if stop_loss_mode != "atr":
        return stop_loss_pct
    if candle.atr is None or candle.atr <= 0:
        return stop_loss_pct
    return max((candle.atr / entry_price) * atr_multiplier, stop_loss_pct)


def _get_exit(
    *,
    candle: SignalCandle,
    index: int,
    position: OpenPosition,
    max_holding_candles: int | None,
) -> tuple[float | None, str]:
    if position.side == "SELL":
        hit_stop_loss = candle.high >= position.stop_loss_price
        hit_take_profit = candle.low <= position.take_profit_price
    else:
        hit_stop_loss = candle.low <= position.stop_loss_price
        hit_take_profit = candle.high >= position.take_profit_price
    hit_time_exit = max_holding_candles is not None and index - position.entry_index >= max_holding_candles

    if hit_stop_loss and hit_take_profit:
        return position.stop_loss_price, "stop_loss"
    if hit_stop_loss:
        return position.stop_loss_price, "stop_loss"
    if hit_take_profit:
        return position.take_profit_price, "take_profit"
    if hit_time_exit:
        return candle.close, "time_exit"
    return None, ""


def _close_position(
    *,
    position: OpenPosition,
    candle: SignalCandle,
    exit_price: float,
    exit_reason: str,
    cash: float,
    fee_rate: float,
) -> tuple[TradeResult, float]:
    exit_value = position.quantity * exit_price
    exit_fee = exit_value * fee_rate
    if position.side == "SELL":
        gross_pnl = (position.entry_price - exit_price) * position.quantity
    else:
        gross_pnl = exit_value - position.allocated_capital
    total_fees = position.entry_fee + exit_fee
    net_pnl = gross_pnl - total_fees
    if position.side == "SELL":
        updated_cash = cash + position.allocated_capital + gross_pnl - exit_fee
    else:
        updated_cash = cash + exit_value - exit_fee

    trade = TradeResult(
        entry_timestamp=position.entry_timestamp,
        exit_timestamp=candle.timestamp,
        side=position.side,
        entry_price=position.entry_price,
        exit_price=exit_price,
        quantity=position.quantity,
        gross_pnl=gross_pnl,
        fees=total_fees,
        net_pnl=net_pnl,
        return_pct=net_pnl / position.allocated_capital,
        exit_reason=exit_reason,
    )
    return trade, updated_cash


def _calculate_mark_to_market_equity(*, cash: float, position: OpenPosition | None, close_price: float) -> float:
    if position is None:
        return cash
    if position.side == "SELL":
        return cash + position.allocated_capital + ((position.entry_price - close_price) * position.quantity)
    return cash + (position.quantity * close_price)


def _calculate_metrics(
    *,
    trades: list[TradeResult],
    initial_capital: float,
    final_equity: float,
    equity_curve: list[EquityPoint],
) -> dict[str, float | int | None]:
    winning_trades = sum(1 for trade in trades if trade.net_pnl > 0)
    losing_trades = sum(1 for trade in trades if trade.net_pnl < 0)
    gross_profit = sum(trade.net_pnl for trade in trades if trade.net_pnl > 0)
    gross_loss = abs(sum(trade.net_pnl for trade in trades if trade.net_pnl < 0))

    profit_factor = None
    if gross_loss > 0:
        profit_factor = gross_profit / gross_loss

    return {
        "winrate": winning_trades / len(trades) if trades else 0.0,
        "max_drawdown": _calculate_max_drawdown(equity_curve=equity_curve, initial_capital=initial_capital),
        "profit_factor": profit_factor,
        "winning_trades": winning_trades,
        "losing_trades": losing_trades,
        "final_equity": final_equity,
    }


def _calculate_max_drawdown(*, equity_curve: list[EquityPoint], initial_capital: float) -> float:
    peak = initial_capital
    max_drawdown = 0.0

    for point in equity_curve:
        peak = max(peak, point.equity)
        if peak <= 0:
            continue
        drawdown = (peak - point.equity) / peak
        max_drawdown = max(max_drawdown, drawdown)

    return max_drawdown
