from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, model_validator


class SignalCandle(BaseModel):
    timestamp: datetime | None = None
    open: float
    high: float
    low: float
    close: float
    volume: float | None = None
    atr: float | None = Field(default=None, gt=0)
    probability: float = Field(..., ge=0, le=1)
    side: Literal["BUY", "SELL", "HOLD"] = "BUY"


class BacktestRequest(BaseModel):
    candles: list[SignalCandle] = Field(..., min_length=2)
    probability_threshold: float = Field(default=0.6, ge=0, le=1)
    initial_capital: float = Field(default=10_000.0, gt=0)
    position_size_fraction: float = Field(default=1.0, gt=0, le=1)
    stop_loss_mode: Literal["fixed", "atr"] = "fixed"
    stop_loss_pct: float = Field(default=0.01, gt=0)
    atr_multiplier: float = Field(default=1.5, gt=0)
    take_profit_pct: float | None = Field(default=None, gt=0)
    take_profit_multiplier: float = Field(default=2.0, gt=0)
    max_holding_candles: int | None = Field(default=None, ge=1)
    fee_rate: float = Field(default=0.0004, ge=0)
    cooldown_after_stop_loss: int = Field(default=0, ge=0)
    cooldown_after_take_profit: int = Field(default=0, ge=0)
    cooldown_after_time_exit: int = Field(default=0, ge=0)
    rearm_probability_threshold: float | None = Field(default=None, ge=0, le=1)

    @model_validator(mode="after")
    def validate_candles(self) -> "BacktestRequest":
        for candle in self.candles:
            if candle.high < candle.low:
                raise ValueError("candle high must be greater than or equal to low")
            if not candle.low <= candle.close <= candle.high:
                raise ValueError("candle close must be between low and high")
            if not candle.low <= candle.open <= candle.high:
                raise ValueError("candle open must be between low and high")
        return self


class TradeResult(BaseModel):
    entry_timestamp: datetime | None
    exit_timestamp: datetime | None
    side: Literal["BUY", "SELL"]
    entry_price: float
    exit_price: float
    quantity: float
    gross_pnl: float
    fees: float
    net_pnl: float
    return_pct: float
    exit_reason: str


class EquityPoint(BaseModel):
    timestamp: datetime | None
    equity: float


class BacktestResponse(BaseModel):
    initial_capital: float
    final_equity: float
    total_pnl: float
    total_return_pct: float
    winrate: float
    max_drawdown: float
    profit_factor: float | None
    total_trades: int
    winning_trades: int
    losing_trades: int
    equity_curve: list[EquityPoint]
    trades: list[TradeResult]
