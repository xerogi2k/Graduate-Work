"""API schemas for backtesting service."""
