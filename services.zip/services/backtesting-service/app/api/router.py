from fastapi import APIRouter, HTTPException, status

from app.core.config import get_settings
from app.schemas.backtest import BacktestRequest, BacktestResponse
from app.services.engine import BacktestError, run_backtest
from shared.schemas.health import HealthResponse

router = APIRouter()


@router.get("/health", response_model=HealthResponse, tags=["system"])
async def health() -> HealthResponse:
    settings = get_settings()
    return HealthResponse(service=settings.service_name)


@router.post("/backtest", response_model=BacktestResponse, tags=["backtesting"])
async def backtest(request: BacktestRequest) -> BacktestResponse:
    try:
        return run_backtest(request)
    except BacktestError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
