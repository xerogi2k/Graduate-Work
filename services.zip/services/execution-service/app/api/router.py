from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.db.session import get_db_session
from app.schemas.paper_trading import CloseTradeRequest, PaperTradeResponse, SubmitSignalRequest
from app.services.paper_trading import PaperTradingError, PaperTradingService
from shared.schemas.health import HealthResponse

router = APIRouter()


@router.get("/health", response_model=HealthResponse, tags=["system"])
async def health() -> HealthResponse:
    settings = get_settings()
    return HealthResponse(service=settings.service_name)


@router.post(
    "/paper/orders",
    response_model=PaperTradeResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["paper-trading"],
)
async def submit_paper_order(
    request: SubmitSignalRequest,
    session: AsyncSession = Depends(get_db_session),
) -> PaperTradeResponse:
    service = PaperTradingService(session=session)
    try:
        trade = await service.open_trade(request)
        await session.commit()
        return PaperTradeResponse.model_validate(trade)
    except PaperTradingError as exc:
        await session.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except SQLAlchemyError as exc:
        await session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to open trade") from exc


@router.post("/paper/close", response_model=PaperTradeResponse, tags=["paper-trading"])
async def close_paper_trade(
    request: CloseTradeRequest,
    session: AsyncSession = Depends(get_db_session),
) -> PaperTradeResponse:
    service = PaperTradingService(session=session)
    try:
        trade = await service.close_trade(request)
        await session.commit()
        return PaperTradeResponse.model_validate(trade)
    except PaperTradingError as exc:
        await session.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except SQLAlchemyError as exc:
        await session.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to close trade") from exc


@router.get("/paper/trades", response_model=list[PaperTradeResponse], tags=["paper-trading"])
async def list_paper_trades(
    symbol: str | None = None,
    status_filter: str | None = None,
    session: AsyncSession = Depends(get_db_session),
) -> list[PaperTradeResponse]:
    service = PaperTradingService(session=session)
    trades = await service.list_trades(symbol=symbol, status=status_filter)
    return [PaperTradeResponse.model_validate(trade) for trade in trades]
