"""Database setup for execution service."""
