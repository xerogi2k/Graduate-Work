from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.paper_trade import PaperTrade


class PaperTradeRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, trade: PaperTrade) -> PaperTrade:
        self._session.add(trade)
        await self._session.flush()
        await self._session.refresh(trade)
        return trade

    async def get(self, trade_id: int) -> PaperTrade | None:
        return await self._session.get(PaperTrade, trade_id)

    async def list(self, *, symbol: str | None = None, status: str | None = None) -> list[PaperTrade]:
        statement = select(PaperTrade).order_by(PaperTrade.opened_at.desc())
        if symbol is not None:
            statement = statement.where(PaperTrade.symbol == symbol.upper())
        if status is not None:
            statement = statement.where(PaperTrade.status == status.upper())
        result = await self._session.execute(statement)
        return list(result.scalars().all())
