from datetime import datetime
from decimal import Decimal

from sqlalchemy import DateTime, Numeric, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class PaperTrade(Base):
    __tablename__ = "paper_trades"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    symbol: Mapped[str] = mapped_column(String(32), index=True)
    side: Mapped[str] = mapped_column(String(8))
    status: Mapped[str] = mapped_column(String(16), index=True, default="OPEN")
    confidence: Mapped[Decimal] = mapped_column(Numeric(10, 6))
    leverage: Mapped[Decimal] = mapped_column(Numeric(10, 4))
    quantity: Mapped[Decimal] = mapped_column(Numeric(28, 12))
    entry_price: Mapped[Decimal] = mapped_column(Numeric(28, 12))
    exit_price: Mapped[Decimal | None] = mapped_column(Numeric(28, 12), nullable=True)
    stop_loss: Mapped[Decimal | None] = mapped_column(Numeric(28, 12), nullable=True)
    take_profit: Mapped[Decimal | None] = mapped_column(Numeric(28, 12), nullable=True)
    notional: Mapped[Decimal] = mapped_column(Numeric(28, 12))
    pnl: Mapped[Decimal | None] = mapped_column(Numeric(28, 12), nullable=True)
    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
