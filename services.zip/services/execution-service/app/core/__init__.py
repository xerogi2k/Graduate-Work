"""Core configuration for execution service."""
