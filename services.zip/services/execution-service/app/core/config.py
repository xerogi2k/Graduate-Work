from functools import lru_cache

from shared.config import BaseServiceSettings


class Settings(BaseServiceSettings):
    service_name: str = "execution-service"
    execution_mode: str = "paper"


@lru_cache
def get_settings() -> Settings:
    return Settings()
