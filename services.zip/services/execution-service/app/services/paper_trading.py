from datetime import UTC, datetime
from decimal import Decimal

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.paper_trade import PaperTrade
from app.repositories.paper_trades import PaperTradeRepository
from app.schemas.paper_trading import CloseTradeRequest, SubmitSignalRequest


class PaperTradingError(RuntimeError):
    """Raised when a paper trading operation is invalid."""


class PaperTradingService:
    def __init__(self, session: AsyncSession) -> None:
        self._repository = PaperTradeRepository(session=session)

    async def open_trade(self, request: SubmitSignalRequest) -> PaperTrade:
        if request.side == "HOLD":
            raise PaperTradingError("HOLD signal cannot open a trade")

        notional = request.entry_price * request.quantity
        trade = PaperTrade(
            symbol=request.symbol.upper(),
            side=request.side,
            status="OPEN",
            confidence=request.confidence,
            leverage=request.leverage,
            quantity=request.quantity,
            entry_price=request.entry_price,
            stop_loss=request.stop_loss,
            take_profit=request.take_profit,
            notional=notional,
        )
        return await self._repository.add(trade)

    async def close_trade(self, request: CloseTradeRequest) -> PaperTrade:
        trade = await self._repository.get(request.trade_id)
        if trade is None:
            raise PaperTradingError(f"Trade {request.trade_id} not found")
        if trade.status != "OPEN":
            raise PaperTradingError(f"Trade {request.trade_id} is already closed")

        trade.exit_price = request.exit_price
        trade.pnl = _calculate_pnl(
            side=trade.side,
            entry_price=trade.entry_price,
            exit_price=request.exit_price,
            quantity=trade.quantity,
        )
        trade.status = "CLOSED"
        trade.closed_at = datetime.now(tz=UTC)
        return trade

    async def list_trades(self, *, symbol: str | None = None, status: str | None = None) -> list[PaperTrade]:
        return await self._repository.list(symbol=symbol, status=status)


def _calculate_pnl(*, side: str, entry_price: Decimal, exit_price: Decimal, quantity: Decimal) -> Decimal:
    if side == "BUY":
        return (exit_price - entry_price) * quantity
    return (entry_price - exit_price) * quantity
