"""Execution service domain logic."""
