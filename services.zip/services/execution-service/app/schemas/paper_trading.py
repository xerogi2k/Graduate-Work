from datetime import datetime
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


Side = Literal["BUY", "SELL", "HOLD"]


class SubmitSignalRequest(BaseModel):
    symbol: str = Field(..., examples=["SOL-USDT"])
    side: Side
    confidence: Decimal = Field(..., ge=0, le=1)
    entry_price: Decimal = Field(..., gt=0)
    quantity: Decimal = Field(..., gt=0)
    leverage: Decimal = Field(default=Decimal("1"), gt=0)
    stop_loss: Decimal | None = Field(default=None, gt=0)
    take_profit: Decimal | None = Field(default=None, gt=0)


class CloseTradeRequest(BaseModel):
    trade_id: int = Field(..., gt=0)
    exit_price: Decimal = Field(..., gt=0)


class PaperTradeResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    symbol: str
    side: str
    status: str
    confidence: Decimal
    leverage: Decimal
    quantity: Decimal
    entry_price: Decimal
    exit_price: Decimal | None
    stop_loss: Decimal | None
    take_profit: Decimal | None
    notional: Decimal
    pnl: Decimal | None
    opened_at: datetime
    closed_at: datetime | None
